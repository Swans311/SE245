﻿using System;

namespace Lab4_Swansey
{
    class ValidationLibrary
    {

        public static bool GotPoop(string temp)
        {
            bool result = false;
            if (temp.Contains("Poopy"))
            {
                result = true;
            }
            return result;
        }

        public static bool IsItFilledIn(string temp)
        {
            bool result = false;
            if (temp.Length > 0)
            {
                result = true;
            }
            return result;
        }

        public static bool IsItFilledIn(string temp, int minlen)
        {
            bool result = false;
            if (temp.Length >= minlen)
            {
                result = true;
            }
            return result;
        }

        public static bool IsItTooLong(string temp, int maxlen)
        {
            bool result = false;
            if (temp.Length <= maxlen)
            {
                result = true;
            }
            return result;
        }

        //Making an email validity checker
        public static bool IsValidEmail(string temp)
        {
            bool blnresult = true;
            int atLocation = temp.IndexOf("@");
            int NextatLocation = temp.IndexOf("@", atLocation + 1);

            int periodLocation = temp.LastIndexOf(".");
            if (temp.Length < 8)
            {
                blnresult = false;
            }
            else if (atLocation < 2)
            {
                blnresult = false;
            }
            else if (periodLocation + 2 > (temp.Length))
            {
                blnresult = false;
            }
            return blnresult;
        }

        public static bool IsMinimumAmount(double temp, double min)
        {
            bool blnresult;

            if (temp >= min)
            {
                blnresult = true;
            }
            else
            {
                blnresult = false;
            }
            return blnresult;
        }

    }
    class Program
    {
        //making the Person Class
        class Person
        {
            //creating all variables for the person struct/class
            private string Fname;
            private string Mname;
            private string Lname;
            private string street1;
            private string street2;
            private string City;
            private string State;
            private string zipcode;
            private string phone;
            private string email;


            //all strings below are referenced as public, so that we are able to access the private strings stored into the Person Class
            //Otherwise we would not be able to pull the information
            public string FName
            {
                get
                {
                    return Fname; //returns the value of the Fname PRIVATE variable
                }
                set
                {//Fname variable will be passed into the "Poopy Checker"
                    if (ValidationLibrary.GotPoop(value))
                    { //if the name contains 'Poopy' leave it as is
                        Fname = value; //sets the Fname var as value, which is then given to the public string FName
                    }
                    else
                    {//otherwise we add poopy to the original value of fname
                        Fname =value + " Poopy";
                    }
                }
            }
            //Below (until Email) are just utilizing basic get/set methods, nothing was to be changed for them
            public string MName
            {
                get
                {
                    return Mname;
                }
                set
                {
                    Mname = value;
                }
            }

            public string LName
            {
                get
                {
                    return Lname;
                }
                set
                {
                    Lname = value;
                }
            }

            public string Street1
            {
                get
                {
                    return street1;
                }
                set
                {
                    street1 = value;
                }
            }

            public string Street2
            {
                get
                {
                    return street2;
                }
                set
                {
                    street2 = value;
                }
            }

            public string city
            {
                get
                {
                    return City;
                }
                set
                {
                    City = value;
                }
            }

            public string state
            {
                get
                {
                    return State;
                }
                set
                {
                    State = value;
                }
            }

            public string Zip
            {
                get
                {
                    return zipcode;
                }
                set
                {
                    zipcode = value;
                }
            }

            public string Phone
            {
                get
                {
                    return phone;
                }
                set
                {

                    phone = value;
                }
            }

            public string Email //using get set method to pull private email variable
            {
                get
                {
                    return email;
                }
                set
                {//inserting Email Validity checker
                    //if the user typed in an @ symbol and  an extention after, the user input for email passes inspection
                    if (ValidationLibrary.IsValidEmail(value))
                    {
                        email = value;
                    }
                    else
                    {//if the above conditions are not met, the email evaluates as invalid
                        email = "INVALID";
                    }
                }
            }
        }




        static void Main(string[] args)
        {//declaring blnresult before use in Person() structure
            bool blnresult = false;
            //setting varible 'temp' for use in Person structure
            Person temp = new Person();

            //USER INPUTS
            Console.Write("Enter first name: ");
            temp.FName = Console.ReadLine(); //temp.PUBLICvariable used so get/set method was used to access variable, and incur no errors
            //temp.FName += " Poopy";


            Console.Write("Enter middle name: ");
            temp.MName = Console.ReadLine();

            Console.Write("Enter last name: ");
            temp.LName = Console.ReadLine();

            Console.Write("Enter Address: ");
            temp.Street1 = Console.ReadLine();

            Console.Write("Enter Apt # (if applicable): ");
            temp.Street2 = Console.ReadLine();

            Console.Write("Enter City/Town: ");
            temp.city = Console.ReadLine();

            Console.Write("Enter State: ");
            temp.state = Console.ReadLine();

            Console.Write("Enter Zip Code: ");
            temp.Zip = Console.ReadLine();


            Console.Write("Enter Phone Number: ");
            temp.Phone = Console.ReadLine();


            Console.Write("Enter Email: ");
            temp.Email = Console.ReadLine();
 

            //outputs were listed like this because of no other reason aside from I liked the way that it looked.
            //as well as not having to use 10 different lines to print out some basic information
            Console.Write($"\n\nYour Name:  {temp.FName} {temp.MName} {temp.LName}"); //User
            Console.Write($"\nYour Address: {temp.Street1} {temp.Street2} {temp.city} {temp.state} {temp.Zip}"); //user's address
            Console.Write($"\nContact Info: {temp.Phone} {temp.Email}"); //user's contact info
            //press any key to exit
            Console.Write("Press any key to exit...");
            Console.ReadKey();
            }


        }
    }


