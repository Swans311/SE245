﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Midterm;

namespace Lab5Final
{
    class Customer:PersonV2
    {
        private DateTime CustomerSince;
        private Double TotalPurchases;
        private Boolean DiscountMember;
        private Int32 RewardsEarned;

        public DateTime customersince
        {
            get
            {
                return CustomerSince;
            }
            set
            {
                if(ValidationLibrary.IsAPastDate(value))
                {
                    CustomerSince = value;
                }
                else
                {
                    feedback += "\nCustomer cannot be from the future";
                    CustomerSince = new DateTime(1/1/2222);
                }
            }
        }
        public Double totalpurchases
        {
            get
            {
                return TotalPurchases;
            }
            set
            {
                if(ValidationLibrary.IsMinimumAmount(value,0))
                {
                    TotalPurchases = value;
                }
                else
                {
                    feedback += "\nCustomer cannot purchase less than $0 worth of merchandise";
                    TotalPurchases = -1;
                }
            }
        }
        public bool discountmember
        {
            get
            {
                return DiscountMember;
            }
            set
            {
                DiscountMember = value;
            }
        }
        public int rewardsearned
        {
            get
            {
                return RewardsEarned;
            }
            set
            {
                if(ValidationLibrary.IsMinimumAmount(value,0))
                {
                    RewardsEarned = value;
                }
                else
                {
                    feedback += "\nEnter an amount greater than or equal to 0";
                    RewardsEarned = -1;
                }
            }
        }
        public Customer()
        {
            RewardsEarned = -1;
            DiscountMember = false;
            TotalPurchases = -1;
            CustomerSince = DateTime.Today;
        }




    }
}
