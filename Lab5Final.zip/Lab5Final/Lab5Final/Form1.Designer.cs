﻿namespace Lab5Final
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Fname = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Mname = new System.Windows.Forms.Label();
            this.street1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.State = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblFeedback = new System.Windows.Forms.Label();
            this.Fnametxt = new System.Windows.Forms.TextBox();
            this.Mnametxt = new System.Windows.Forms.TextBox();
            this.Lnametxt = new System.Windows.Forms.TextBox();
            this.street1txt = new System.Windows.Forms.TextBox();
            this.street2txt = new System.Windows.Forms.TextBox();
            this.citytxt = new System.Windows.Forms.TextBox();
            this.statetxt = new System.Windows.Forms.TextBox();
            this.ziptxt = new System.Windows.Forms.TextBox();
            this.phonetxt = new System.Windows.Forms.TextBox();
            this.emailtxt = new System.Windows.Forms.TextBox();
            this.celltxt = new System.Windows.Forms.TextBox();
            this.instagramtxt = new System.Windows.Forms.TextBox();
            this.totalpurchtxt = new System.Windows.Forms.TextBox();
            this.Rewardstxt = new System.Windows.Forms.TextBox();
            this.dtpicker = new System.Windows.Forms.DateTimePicker();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.Discountbox = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // Fname
            // 
            this.Fname.AutoSize = true;
            this.Fname.Location = new System.Drawing.Point(67, 9);
            this.Fname.Name = "Fname";
            this.Fname.Size = new System.Drawing.Size(122, 25);
            this.Fname.TabIndex = 0;
            this.Fname.Text = "First Name:";
            this.Fname.Click += new System.EventHandler(this.Fname_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Last Name:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Mname
            // 
            this.Mname.AutoSize = true;
            this.Mname.Location = new System.Drawing.Point(45, 47);
            this.Mname.Name = "Mname";
            this.Mname.Size = new System.Drawing.Size(144, 25);
            this.Mname.TabIndex = 2;
            this.Mname.Text = "Middle Name:";
            this.Mname.Click += new System.EventHandler(this.Mname_Click);
            // 
            // street1
            // 
            this.street1.AutoSize = true;
            this.street1.Location = new System.Drawing.Point(74, 121);
            this.street1.Name = "street1";
            this.street1.Size = new System.Drawing.Size(115, 25);
            this.street1.TabIndex = 3;
            this.street1.Text = "Address 1:";
            this.street1.Click += new System.EventHandler(this.street1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(74, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = "Address 2:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(82, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 25);
            this.label5.TabIndex = 5;
            this.label5.Text = "City/Town";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // State
            // 
            this.State.AutoSize = true;
            this.State.Location = new System.Drawing.Point(121, 238);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(68, 25);
            this.State.TabIndex = 6;
            this.State.Text = "State:";
            this.State.Click += new System.EventHandler(this.State_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(84, 274);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 25);
            this.label7.TabIndex = 7;
            this.label7.Text = "Zip Code:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 312);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(161, 25);
            this.label8.TabIndex = 8;
            this.label8.Text = "Phone Number:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(118, 353);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 25);
            this.label9.TabIndex = 9;
            this.label9.Text = "Email:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 391);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 25);
            this.label2.TabIndex = 10;
            this.label2.Text = "Cell Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(77, 440);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 25);
            this.label3.TabIndex = 11;
            this.label3.Text = "Instagram:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 484);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(170, 25);
            this.label6.TabIndex = 12;
            this.label6.Text = "Customer Since:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 528);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(174, 25);
            this.label10.TabIndex = 13;
            this.label10.Text = "Total Purchases:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 571);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(186, 25);
            this.label11.TabIndex = 14;
            this.label11.Text = "Discount Member:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 615);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(177, 25);
            this.label12.TabIndex = 15;
            this.label12.Text = "Rewards Earned:";
            // 
            // lblFeedback
            // 
            this.lblFeedback.AutoSize = true;
            this.lblFeedback.Location = new System.Drawing.Point(76, 787);
            this.lblFeedback.Name = "lblFeedback";
            this.lblFeedback.Size = new System.Drawing.Size(113, 25);
            this.lblFeedback.TabIndex = 16;
            this.lblFeedback.Text = "Feedback:";
            // 
            // Fnametxt
            // 
            this.Fnametxt.Location = new System.Drawing.Point(254, 3);
            this.Fnametxt.Name = "Fnametxt";
            this.Fnametxt.Size = new System.Drawing.Size(544, 31);
            this.Fnametxt.TabIndex = 17;
            // 
            // Mnametxt
            // 
            this.Mnametxt.Location = new System.Drawing.Point(254, 41);
            this.Mnametxt.Name = "Mnametxt";
            this.Mnametxt.Size = new System.Drawing.Size(544, 31);
            this.Mnametxt.TabIndex = 18;
            // 
            // Lnametxt
            // 
            this.Lnametxt.Location = new System.Drawing.Point(254, 78);
            this.Lnametxt.Name = "Lnametxt";
            this.Lnametxt.Size = new System.Drawing.Size(544, 31);
            this.Lnametxt.TabIndex = 19;
            // 
            // street1txt
            // 
            this.street1txt.Location = new System.Drawing.Point(254, 115);
            this.street1txt.Name = "street1txt";
            this.street1txt.Size = new System.Drawing.Size(544, 31);
            this.street1txt.TabIndex = 20;
            // 
            // street2txt
            // 
            this.street2txt.Location = new System.Drawing.Point(254, 156);
            this.street2txt.Name = "street2txt";
            this.street2txt.Size = new System.Drawing.Size(544, 31);
            this.street2txt.TabIndex = 21;
            // 
            // citytxt
            // 
            this.citytxt.Location = new System.Drawing.Point(254, 192);
            this.citytxt.Name = "citytxt";
            this.citytxt.Size = new System.Drawing.Size(544, 31);
            this.citytxt.TabIndex = 22;
            // 
            // statetxt
            // 
            this.statetxt.Location = new System.Drawing.Point(254, 232);
            this.statetxt.MaxLength = 2;
            this.statetxt.Name = "statetxt";
            this.statetxt.Size = new System.Drawing.Size(544, 31);
            this.statetxt.TabIndex = 23;
            // 
            // ziptxt
            // 
            this.ziptxt.Location = new System.Drawing.Point(254, 268);
            this.ziptxt.MaxLength = 5;
            this.ziptxt.Name = "ziptxt";
            this.ziptxt.Size = new System.Drawing.Size(544, 31);
            this.ziptxt.TabIndex = 24;
            // 
            // phonetxt
            // 
            this.phonetxt.Location = new System.Drawing.Point(254, 306);
            this.phonetxt.MaxLength = 10;
            this.phonetxt.Name = "phonetxt";
            this.phonetxt.Size = new System.Drawing.Size(544, 31);
            this.phonetxt.TabIndex = 25;
            // 
            // emailtxt
            // 
            this.emailtxt.Location = new System.Drawing.Point(254, 347);
            this.emailtxt.Name = "emailtxt";
            this.emailtxt.Size = new System.Drawing.Size(544, 31);
            this.emailtxt.TabIndex = 26;
            // 
            // celltxt
            // 
            this.celltxt.Location = new System.Drawing.Point(254, 384);
            this.celltxt.MaxLength = 10;
            this.celltxt.Name = "celltxt";
            this.celltxt.Size = new System.Drawing.Size(544, 31);
            this.celltxt.TabIndex = 27;
            // 
            // instagramtxt
            // 
            this.instagramtxt.Location = new System.Drawing.Point(254, 434);
            this.instagramtxt.Name = "instagramtxt";
            this.instagramtxt.Size = new System.Drawing.Size(544, 31);
            this.instagramtxt.TabIndex = 28;
            // 
            // totalpurchtxt
            // 
            this.totalpurchtxt.Location = new System.Drawing.Point(254, 522);
            this.totalpurchtxt.Name = "totalpurchtxt";
            this.totalpurchtxt.Size = new System.Drawing.Size(544, 31);
            this.totalpurchtxt.TabIndex = 30;
            this.totalpurchtxt.Text = "0.00";
            // 
            // Rewardstxt
            // 
            this.Rewardstxt.Location = new System.Drawing.Point(254, 609);
            this.Rewardstxt.Name = "Rewardstxt";
            this.Rewardstxt.Size = new System.Drawing.Size(544, 31);
            this.Rewardstxt.TabIndex = 32;
            this.Rewardstxt.Text = "0";
            // 
            // dtpicker
            // 
            this.dtpicker.Location = new System.Drawing.Point(254, 478);
            this.dtpicker.Name = "dtpicker";
            this.dtpicker.Size = new System.Drawing.Size(394, 31);
            this.dtpicker.TabIndex = 33;
            // 
            // SubmitButton
            // 
            this.SubmitButton.Location = new System.Drawing.Point(684, 688);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(114, 42);
            this.SubmitButton.TabIndex = 34;
            this.SubmitButton.Text = "Submit";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // Discountbox
            // 
            this.Discountbox.AutoSize = true;
            this.Discountbox.Location = new System.Drawing.Point(254, 569);
            this.Discountbox.Name = "Discountbox";
            this.Discountbox.Size = new System.Drawing.Size(28, 27);
            this.Discountbox.TabIndex = 35;
            this.Discountbox.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1269, 987);
            this.Controls.Add(this.Discountbox);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.dtpicker);
            this.Controls.Add(this.Rewardstxt);
            this.Controls.Add(this.totalpurchtxt);
            this.Controls.Add(this.instagramtxt);
            this.Controls.Add(this.celltxt);
            this.Controls.Add(this.emailtxt);
            this.Controls.Add(this.phonetxt);
            this.Controls.Add(this.ziptxt);
            this.Controls.Add(this.statetxt);
            this.Controls.Add(this.citytxt);
            this.Controls.Add(this.street2txt);
            this.Controls.Add(this.street1txt);
            this.Controls.Add(this.Lnametxt);
            this.Controls.Add(this.Mnametxt);
            this.Controls.Add(this.Fnametxt);
            this.Controls.Add(this.lblFeedback);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.State);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.street1);
            this.Controls.Add(this.Mname);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Fname);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Fname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Mname;
        private System.Windows.Forms.Label street1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label State;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblFeedback;
        private System.Windows.Forms.TextBox Fnametxt;
        private System.Windows.Forms.TextBox Mnametxt;
        private System.Windows.Forms.TextBox Lnametxt;
        private System.Windows.Forms.TextBox street1txt;
        private System.Windows.Forms.TextBox street2txt;
        private System.Windows.Forms.TextBox citytxt;
        private System.Windows.Forms.TextBox statetxt;
        private System.Windows.Forms.TextBox ziptxt;
        private System.Windows.Forms.TextBox phonetxt;
        private System.Windows.Forms.TextBox emailtxt;
        private System.Windows.Forms.TextBox celltxt;
        private System.Windows.Forms.TextBox instagramtxt;
        private System.Windows.Forms.TextBox totalpurchtxt;
        private System.Windows.Forms.TextBox Rewardstxt;
        private System.Windows.Forms.DateTimePicker dtpicker;
        private System.Windows.Forms.Button SubmitButton;
        private System.Windows.Forms.CheckBox Discountbox;
    }
}

