﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5Final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void State_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void street1_Click(object sender, EventArgs e)
        {

        }

        private void Mname_Click(object sender, EventArgs e)
        {

        }

        private void Fname_Click(object sender, EventArgs e)
        {

        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            Customer temp = new Customer();

            temp.FName = Fnametxt.Text;
            temp.MName = Mnametxt.Text;
            temp.LName = Lnametxt.Text;
            temp.Street1 = street1txt.Text;
            temp.Street2 = street2txt.Text;
            temp.city = citytxt.Text;
            temp.state = statetxt.Text;
            temp.Zip = ziptxt.Text;
            temp.Phone = phonetxt.Text;
            temp.Email = emailtxt.Text;
            temp.cellphone = celltxt.Text;
            temp.instagram = instagramtxt.Text;
            temp.customersince = dtpicker.Value;
            temp.totalpurchases = Convert.ToDouble(totalpurchtxt.Text);
            temp.discountmember =Discountbox.Checked;
            temp.rewardsearned = Convert.ToInt32(Rewardstxt.Text);


            if (temp.FName.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.LName.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.Street1.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.city.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.state.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.Zip.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.Phone.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.Email.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.cellphone.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
 




            else
            {
                lblFeedback.Text = ($"{temp.FName} {temp.MName} {temp.LName} \nLocated at: {temp.Street1} {temp.Street2} in {temp.city}, {temp.state} {temp.Zip} \nCan be contacted via Phone: {temp.Phone} or Email: {temp.Email} \nCell Phone Number: {temp.cellphone} and found on Instagram: @{temp.instagram} \n{temp.FName} has been a customer since {temp.customersince} \nHas purchased ${temp.totalpurchases} worth of goods \nThe results are in and {temp.FName}'s Discount Member status has been determined to be {temp.discountmember} \nThey have recieved {temp.rewardsearned} rewards through our Rewards Program");
            }



        }
    }
}
