﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Midterm;
using System.Data;
using System.Data.SqlClient;
using Lab5;

namespace Person2
{
        class PersonV2 : Person
        {
            private string CellPhone;
            private string Instagram;

            public string cellNumber
            {
                get
                {
                    return CellPhone;
                }
                set
                {
                    if (ValidationLibrary.IsItFilledIn(value, 10))
                    {
                        CellPhone = value;
                    }
                    else if (ValidationLibrary.IsItTooLong(value, 10))
                    {
                        feedback += "\nERROR: Cell Number was not long enough";
                        CellPhone = "ERROR";
                    }
                    else
                    {
                        feedback += "\nERROR: Cell Number was invalid";
                        CellPhone = "ERROR";
                    }

                }
            }
            public string instagram
            {
                get
                {
                    return Instagram;
                }
                set
                {//no validation because not everyone has instagram...
                    Instagram = value;
                }
            }
            public PersonV2() 
            {
                Instagram = "";
                CellPhone = "1231231234";

            }

            public string AddARecord()
            {
                string strResult = "";
                SqlConnection Conn = new SqlConnection();

                Conn.ConnectionString = @"Server=sql.neit.edu\sqlstudentserver,4500;Database=SE245_DSwansey; User Id=SE245_DSwansey; Password=008008985";

                string strSQL = "Insert Into PersonV2 (FName, MName, LName, Street1, Street2, city, state, Zipcode, PhoneNumber, Email, cellNumber, instagram) VALUES (@FName, @MName, @LName, @Street1, @Street2, @City, @State, @Zipcode, @PhoneNumber, @Email, @CellNumber,  @Instagram)";

                SqlCommand comm = new SqlCommand();
                comm.CommandText = strSQL;
                comm.Connection = Conn;

                comm.Parameters.AddWithValue("@FName", FName);
                comm.Parameters.AddWithValue("@MName", MName);
                comm.Parameters.AddWithValue("@LName", LName);
                comm.Parameters.AddWithValue("@Street1", Street1);
                comm.Parameters.AddWithValue("@Street2", Street2);
                comm.Parameters.AddWithValue("@City", city);
                comm.Parameters.AddWithValue("@State", state);
                comm.Parameters.AddWithValue("@Zipcode", Zipcode);
                comm.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
                comm.Parameters.AddWithValue("@Email", Email);
                comm.Parameters.AddWithValue("@CellNumber", cellNumber);
                comm.Parameters.AddWithValue("@Instagram", instagram);






                try
                {
                    Conn.Open();
                    int intRecs = comm.ExecuteNonQuery();
                    strResult = $"SUCCESS: Inserted {intRecs} records";
                    Conn.Close();
                }
                catch (Exception err)
                {
                    strResult = "ERROR:" + err.Message;
                }
                finally
                {

                }
                return strResult;
            }



        }
    }






