﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Midterm;

namespace Lab5
{

        class Person
        {
            //creating all variables for the person struct/class
            private string Fname;
            private string Mname;
            private string Lname;
            private string street1;
            private string street2;
            private string City;
            private string State;
            private string zipcode;
            private string phone;
            private string email;
            private string Feedback = "";


            //all strings below are referenced as public, so that we are able to access the private strings stored into the Person Class
            //Otherwise we would not be able to pull the information
            public string FName
            {
                get
                {
                    return Fname; //returns the value of the Fname PRIVATE variable
                }
                set
                {//Fname variable will be passed into the "Poopy Checker"
                    if (ValidationLibrary.IsItFilledIn(value, 1) && !ValidationLibrary.GotBadWords(value))
                    { //if the name contains 'Poopy' leave it as is
                        Fname = value; //sets the Fname var as value, which is then given to the public string FName
                    }
                    else if (ValidationLibrary.GotBadWords(value))
                    {
                        Fname = "ERROR";
                        Feedback += "\nERROR: FIRST NAME CONTAINS BAD WORDS";
                    }
                    else
                    {
                        Fname = "ERROR";
                        Feedback += "\nERROR: First name must be filled in";
                    }
                }
            }
            //Below (until Email) are just utilizing basic get/set methods, nothing was to be changed for them

            public string feedback
            {
                get
                {
                    return Feedback;
                }
                set
                {
                    Feedback = value;
                }
            }

            public string MName
            {
                get
                {
                    return Mname;
                }
                set
                {
                    if (!ValidationLibrary.GotBadWords(value))
                    { Mname = value; }

                    else if (ValidationLibrary.GotBadWords(value))
                    {
                        Mname = "ERROR";
                        Feedback += "\nERROR: MIDDLE NAME CONTAINS BAD WORDS";
                    }
                }
            }

            public string LName
            {
                get
                {
                    return Lname;
                }
                set
                {
                    if (ValidationLibrary.IsItFilledIn(value, 1) && !ValidationLibrary.GotBadWords(value))
                    {
                        Lname = value;
                    }
                    else if (ValidationLibrary.GotBadWords(value))
                    {
                        Lname = "ERROR";
                        Feedback += "ERROR: MIDDLE NAME CONTAINS BAD WORDS";
                    }
                    else
                    {
                        Lname = "ERROR";
                        Feedback = "\nERROR: Last name must be filled in";
                    }
                }
            }

            public string Street1
            {
                get
                {
                    return street1;
                }
                set
                {
                    //although there are homeless people, we must include a small validation to include an address check
                    if (ValidationLibrary.IsItFilledIn(value, 1))
                    {
                        street1 = value;
                    }
                    else
                    {
                        street1 = "ERROR";
                        Feedback += "\nERROR: Address 1 must be filled in";
                    }
                }
            }

            public string Street2
            {
                get
                {
                    return street2;
                }
                set
                {
                    street2 = value;
                }
            }

            public string city
            {
                get
                {
                    return City;
                }
                set
                {
                    if (ValidationLibrary.IsItFilledIn(value, 1))
                    {
                        City = value;
                    }
                    else
                    {
                        City = "ERROR";
                        Feedback += "\nERROR: City must be filled in";
                    }
                }
            }

            public string state
            {
                get
                {
                    return State;
                }
                set
                {
                    if (ValidationLibrary.IsItFilledIn(value, 2))
                    {
                        State = value;
                    }
                    else
                    {
                        Feedback += "\nERROR State Not Long Enough";
                        State = "ERROR";
                    }
                }
            }

            public string Zipcode
            {
                get
                {
                    return zipcode;
                }
                set
                {
                    if (ValidationLibrary.IsItFilledIn(value, 5))
                    {
                        zipcode = value;
                    }
                    else if (ValidationLibrary.IsItTooLong(value, 5))
                    {
                        Feedback += "\nERROR: Zip was not long enough";
                        zipcode = "ERR";
                    }
                    else
                    {
                        Feedback += "\nERROR: Zip Code was invalid";
                    }
                }
            }

            public string PhoneNumber
            {
                get
                {
                    return phone;
                }
                set
                {
                    if (ValidationLibrary.IsItFilledIn(value, 10))
                    {
                        phone = value;
                    }
                    else if (ValidationLibrary.IsItTooLong(value, 10))
                    {
                        Feedback += "\nERROR: Phone Number was not long enough";
                        phone = "ERROR";
                    }
                        else
                    {
                    Feedback += "\nERROR: Phone Number was invalid";
                    }

                    phone = value;
                }
            }

            public string Email //using get set method to pull private email variable
            {
                get
                {
                    return email;
                }
                set
                {//inserting Email Validity checker
                 //if the user typed in an @ symbol and  an extention after, the user input for email passes inspection
                    if (ValidationLibrary.IsValidEmail(value))
                    {
                        email = value;
                    }
                    else
                    {//if the above conditions are not met, the email evaluates as invalid
                        Feedback += "\nERROR invalid Email format";
                        email = "ERROR";
                    }
                }
            }
            public Person()
            {
                Fname = "";
                Mname = "";
                Lname = "";
                street1 = "";
                street2 = "";
                City = "";
                State = "";
                zipcode = "";
                email = "";
                phone = "";
                Feedback = "";
            }






        }
    }

