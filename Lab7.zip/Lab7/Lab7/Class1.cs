﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Midterm;
using System.Data;
using System.Data.SqlClient;


namespace Midterm
{
    class ValidationLibrary
    {

        public static bool GotPoop(string temp)
        {
            bool result = false;
            if (temp.Contains("Poopy"))
            {
                result = true;
            }
            return result;
        }

        public static bool IsItFilledIn(string temp)
        {
            bool result = false;
            if (temp.Length > 0)
            {
                result = true;
            }
            return result;
        }

        public static bool IsItFilledIn(string temp, int minlen)
        {
            bool result = false;
            if (temp.Length >= minlen)
            {
                result = true;
            }
            return result;
        }

        public static bool IsItTooLong(string temp, int maxlen)
        {
            bool result = false;
            if (temp.Length <= maxlen)
            {
                result = true;
            }
            return result;
        }

        //Making an email validity checker
        public static bool IsValidEmail(string temp)
        {
            bool blnresult = true;
            int atLocation = temp.IndexOf("@");
            int NextatLocation = temp.IndexOf("@", atLocation + 1);

            int periodLocation = temp.LastIndexOf(".");
            if (temp.Length < 8)
            {
                blnresult = false;
            }
            else if (atLocation < 2)
            {
                blnresult = false;
            }
            else if (periodLocation + 2 > (temp.Length))
            {
                blnresult = false;
            }
            return blnresult;
        }

        public static bool IsMinimumAmount(double temp, double min)
        {
            bool blnresult;

            if (temp >= min)
            {
                blnresult = true;
            }
            else
            {
                blnresult = false;
            }
            return blnresult;
        }
        public static bool IsMinimumAmount(int temp, int min)
        {
            bool blnresult;

            if (temp >= min)
            {
                blnresult = true;
            }
            else
            {
                blnresult = false;
            }
            return blnresult;
        }

        public static bool IsAPastDate(DateTime temp)
        {
            bool blnResult;
            if(temp > DateTime.Now)
            {
                blnResult = false;
            }
            else
            {
                blnResult = true;
            }
            return blnResult;
        }


        public static bool GotBadWords(string temp)
        {
            bool result = false;
            string[] strBadWords = { "POOP", "HOMEWORK", "CACA" };
            foreach(string strBW in strBadWords)
                if(temp.Contains(strBW))
                {
                    result = true;
                }
            return result;
        }


    }
    class Person
    {
        //creating all variables for the person struct/class
        private string Fname;
        private string Mname;
        private string Lname;
        private string street1;
        private string street2;
        private string City;
        private string State;
        private string zipcode;
        private string phone;
        private string email;
        private string Feedback = "";


        //all strings below are referenced as public, so that we are able to access the private strings stored into the Person Class
        //Otherwise we would not be able to pull the information
        public string FName
        {
            get
            {
                return Fname; //returns the value of the Fname PRIVATE variable
            }
            set
            {//Fname variable will be passed into the "Poopy Checker"
                if (ValidationLibrary.IsItFilledIn(value,1)&& !ValidationLibrary.GotBadWords(value))
                { //if the name contains 'Poopy' leave it as is
                    Fname = value; //sets the Fname var as value, which is then given to the public string FName
                }
                else if(ValidationLibrary.GotBadWords(value))
                {
                    Fname = "ERROR";
                    Feedback += "\nERROR: FIRST NAME CONTAINS BAD WORDS";
                }
                else
                {
                    Fname = "ERROR";
                    Feedback += "\nERROR: First name must be filled in";
                }
            }
        }
        //Below (until Email) are just utilizing basic get/set methods, nothing was to be changed for them

        public string feedback
        {
            get
            {
                return Feedback;
            }
            set
            {
                Feedback = value;
            }
        }

        public string MName
        {
            get
            {
                return Mname;
            }
            set
            {
                if (!ValidationLibrary.GotBadWords(value))
                { Mname = value; }

                else if (ValidationLibrary.GotBadWords(value))
                {
                    Mname = "ERROR";
                    Feedback += "\nERROR: MIDDLE NAME CONTAINS BAD WORDS";
                }
            }
        }

        public string LName
        {
            get
            {
                return Lname;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value, 1)&& !ValidationLibrary.GotBadWords(value))
                {
                    Lname = value;
                }
                else if (ValidationLibrary.GotBadWords(value))
                {
                    Lname = "ERROR";
                    Feedback += "ERROR: MIDDLE NAME CONTAINS BAD WORDS";
                }
                else
                {
                    Lname = "ERROR";
                    Feedback = "\nERROR: Last name must be filled in";
                }
            }
        }

        public string Street1
        {
            get
            {
                return street1;
            }
            set
            {
                //although there are homeless people, we must include a small validation to include an address check
                if (ValidationLibrary.IsItFilledIn(value, 1))
                {
                    street1 = value;
                }
                else
                {
                    street1 = "ERROR";
                    Feedback += "\nERROR: Address 1 must be filled in";
                }
            }
        }

        public string Street2
        {
            get
            {
                return street2;
            }
            set
            {
                street2 = value;
            }
        }

        public string city
        {
            get
            {
                return City;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value, 1))
                {
                    City = value;
                }
                else
                {
                    City = "ERROR";
                    Feedback += "\nERROR: City must be filled in";
                }
            }
        }

        public string state
        {
            get
            {
                return State;
            }
            set
            {
                if(ValidationLibrary.IsItFilledIn(value,2))
                {
                    State = value;
                }
                else
                {
                    Feedback += "\nERROR State Not Long Enough";
                    State = "ERROR";
                }
            }
        }

        public string Zipcode
        {
            get
            {
                return zipcode;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value, 5))
                {
                zipcode = value;
                }
                else
                {
                    Feedback += "\nERROR: Zip Code not long enough";
                    zipcode = "ERROR: Zip Code not long enough";
                }
            }
        }

        public string PhoneNumber
        {
            get
            {
                return phone;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value, 10))
                {
                    phone = value;
                }
                else if (ValidationLibrary.IsItTooLong(value, 10))
                {
                    Feedback += "ERROR: Phone Number was not long enough";
                    phone = "ERROR";
                }
                else
                {
                    Feedback += "\nERROR: Phone number not long enough";
                    phone = "ERROR";
                }

                phone = value;
            }
        }

        public string Email //using get set method to pull private email variable
        {
            get
            {
                return email;
            }
            set
            {//inserting Email Validity checker
             //if the user typed in an @ symbol and  an extention after, the user input for email passes inspection
                if (ValidationLibrary.IsValidEmail(value))
                {
                    email = value;
                }
                else
                {//if the above conditions are not met, the email evaluates as invalid
                    Feedback += "\nERROR invalid Email format";
                    email = "ERROR";
                }
            }
        }
        public Person()
        {
            Fname = "";
            Mname = "";
            Lname = "";
            street1 = "";
            street2 = "";
            City = "";
            State = "";
            zipcode = "";
            email = "";
            phone = "";
            Feedback = "";
        }






    }
    class PersonV2 : Person
    {
        private string CellPhone;
        private string Instagram;

        public string cellNumber
        {
            get
            {
                return CellPhone;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value, 10))
                {
                    CellPhone = value;
                }
                else
                {
                    feedback += "\nERROR: Cell Phone number not long enough";
                    CellPhone = "ERROR";
                }
            }
        }
        public string instagram
        {
            get
            {
                return Instagram;
            }
            set
            {//no validation because not everyone has instagram...
                Instagram = value;
            }
        }
        public PersonV2()
        {
            Instagram = "";
            CellPhone = "1231231234";

        }

        public string AddARecord()
        {
            string strResult = "";
            SqlConnection Conn = new SqlConnection();

            Conn.ConnectionString = @"Server=sql.neit.edu\sqlstudentserver,4500;Database=SE245_DSwansey; User Id=SE245_DSwansey; Password=008008985";

            string strSQL = "Insert Into PersonV2 (FName, MName, LName, Street1, Street2, city, state, Zipcode, PhoneNumber, Email, cellNumber, instagram) VALUES (@FName, @MName, @LName, @Street1, @Street2, @City, @State, @Zipcode, @PhoneNumber, @Email, @CellNumber,  @Instagram)";

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = Conn;

            comm.Parameters.AddWithValue("@FName", FName);
            comm.Parameters.AddWithValue("@MName", MName);
            comm.Parameters.AddWithValue("@LName", LName);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2);
            comm.Parameters.AddWithValue("@City",city);
            comm.Parameters.AddWithValue("@State",state);
            comm.Parameters.AddWithValue("@Zipcode",Zipcode);
            comm.Parameters.AddWithValue("@PhoneNumber",PhoneNumber);
            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("@CellNumber",cellNumber);
            comm.Parameters.AddWithValue("@Instagram",instagram);






            try
            {
                Conn.Open();
                int intRecs = comm.ExecuteNonQuery();
                strResult = $"SUCCESS: Inserted {intRecs} records";
                Conn.Close();
            }
            catch (Exception err)
            {
                strResult = "ERROR:" + err.Message;
            }
            finally
            {

            }
            return strResult;
        }



    }
}
