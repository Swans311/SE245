﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Midterm;
using System.Data;
using System.Data.SqlClient;

namespace Lab7
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Ensure the quality of Input, or you will need to start over.\n\n");
            PersonV2 temp = new PersonV2();

            Console.Write("Enter First Name:");
            temp.FName = Console.ReadLine();

            Console.Write("Enter middle name: ");
            temp.MName = Console.ReadLine();

            Console.Write("Enter last name: ");
            temp.LName = Console.ReadLine();

            Console.Write("Enter Address: ");
            temp.Street1 = Console.ReadLine();

            Console.Write("Enter Apt # (if applicable): ");
            temp.Street2 = Console.ReadLine();

            Console.Write("Enter City/Town: ");
            temp.city = Console.ReadLine();

            Console.Write("Enter State: ");
            temp.state = Console.ReadLine();

            Console.Write("Enter Zip Code: ");
            temp.Zipcode = Console.ReadLine();


            Console.Write("Enter Phone Number: ");
            temp.PhoneNumber = Console.ReadLine();


            Console.Write("Enter Email: ");
            temp.Email = Console.ReadLine();

            Console.Write("Enter Cell Number: ");
            temp.cellNumber = Console.ReadLine();

            Console.Write("Enter Instagram Username: @");
            temp.instagram = Console.ReadLine();

            if(temp.feedback.Contains("ERROR"))
            {
                Console.WriteLine($"{temp.feedback} was input incorrectly. \nPlease Try Again");
                Console.Write("\n\nEnter First Name:");
                temp.FName = Console.ReadLine();

                Console.Write("Enter middle name: ");
                temp.MName = Console.ReadLine();

                Console.Write("Enter last name: ");
                temp.LName = Console.ReadLine();

                Console.Write("Enter Address: ");
                temp.Street1 = Console.ReadLine();

                Console.Write("Enter Apt # (if applicable): ");
                temp.Street2 = Console.ReadLine();

                Console.Write("Enter City/Town: ");
                temp.city = Console.ReadLine();

                Console.Write("Enter State: ");
                temp.state = Console.ReadLine();

                Console.Write("Enter Zip Code: ");
                temp.Zipcode = Console.ReadLine();


                Console.Write("Enter Phone Number: ");
                temp.PhoneNumber = Console.ReadLine();


                Console.Write("Enter Email: ");
                temp.Email = Console.ReadLine();

                Console.Write("Enter Cell Number: ");
                temp.cellNumber = Console.ReadLine();

                Console.Write("Enter Instagram Username: @");
                temp.instagram = Console.ReadLine();
            }

            if (temp.feedback.Contains("ERROR"))
            {
                string strFeedback = temp.AddARecord();
                Console.WriteLine(strFeedback);
            }
            else
            {
                string strFeedback = temp.AddARecord();
                Console.WriteLine(strFeedback);
            }
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}
