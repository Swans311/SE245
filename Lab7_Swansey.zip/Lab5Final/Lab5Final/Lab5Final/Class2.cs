﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Midterm;
using System.Data;
using System.Data.SqlClient;
using Lab5;

namespace Person2
{
        class PersonV2 : Person
        {
            private string CellPhone;
            private string Instagram;

            public string cellNumber
            {
                get
                {
                    return CellPhone;
                }
                set
                {
                    if (ValidationLibrary.IsItFilledIn(value, 10))
                    {
                        CellPhone = value;
                    }
                    else if (ValidationLibrary.IsItTooLong(value, 10))
                    {
                        feedback += "\nERROR: Cell Number was not long enough";
                        CellPhone = "ERROR";
                    }
                    else
                    {
                        feedback += "\nERROR: Cell Number was invalid";
                        CellPhone = "ERROR";
                    }

                }
            }
            public string instagram
            {
                get
                {
                    return Instagram;
                }
                set
                {//no validation because not everyone has instagram...
                    Instagram = value;
                }
            }
            public PersonV2() 
            {
                Instagram = "";
                CellPhone = "1231231234";

            }

            public string AddARecord()
            {
                string strResult = "";
                SqlConnection Conn = new SqlConnection();

                Conn.ConnectionString = @"Server=sql.neit.edu\sqlstudentserver,4500;Database=SE245_DSwansey; User Id=SE245_DSwansey; Password=008008985";

                string strSQL = "Insert Into PersonV2 (FName, MName, LName, Street1, Street2, city, state, Zipcode, PhoneNumber, Email, cellNumber, instagram) VALUES (@FName, @MName, @LName, @Street1, @Street2, @City, @State, @Zipcode, @PhoneNumber, @Email, @CellNumber,  @Instagram)";

                SqlCommand comm = new SqlCommand();
                comm.CommandText = strSQL;
                comm.Connection = Conn;

                comm.Parameters.AddWithValue("@FName", FName);
                comm.Parameters.AddWithValue("@MName", MName);
                comm.Parameters.AddWithValue("@LName", LName);
                comm.Parameters.AddWithValue("@Street1", Street1);
                comm.Parameters.AddWithValue("@Street2", Street2);
                comm.Parameters.AddWithValue("@City", city);
                comm.Parameters.AddWithValue("@State", state);
                comm.Parameters.AddWithValue("@Zipcode", Zipcode);
                comm.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
                comm.Parameters.AddWithValue("@Email", Email);
                comm.Parameters.AddWithValue("@CellNumber", cellNumber);
                comm.Parameters.AddWithValue("@Instagram", instagram);






                try
                {
                    Conn.Open();
                    int intRecs = comm.ExecuteNonQuery();
                    strResult = $"SUCCESS: Inserted {intRecs} records";
                    Conn.Close();
                }
                catch (Exception err)
                {
                    strResult = "ERROR:" + err.Message;
                }
                finally
                {

                }
                return strResult;
            }

        public DataSet SearchPersonV2(String strEmail, String strLName)
        {
            DataSet ds = new DataSet();

            SqlCommand comm = new SqlCommand();

            String strSQL = "SELECT PersonID, FName, MName, LName, Street1, Street2, City, State, Zipcode, PhoneNumber, Email, CellNumber, Instagram FROM Personv2 WHERE 0=0 ";

            if(strEmail.Length> 0 )
            {
                strSQL += "AND Email LIKE @Email";
                comm.Parameters.AddWithValue("@Email", "%" + strEmail + "%");
            }
            if (strLName.Length > 0)
            {
                strSQL += "AND LName LIKE @LName";
                comm.Parameters.AddWithValue("@LName", "%" + strLName + "%");
            }


            SqlConnection conn = new SqlConnection();
            string strConn = @GetConnected();
            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = strSQL;

            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();
            da.Fill(ds, "personv2_Temp");
            conn.Close();

            return ds;
        }

        public SqlDataReader FindOnePerson(int intPersonID)
        {
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            string strConn = GetConnected();

            string sqlString = "SELECT * FROM Personv2 WHERE PersonID = @PersonID";

            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@PersonID", intPersonID);

            conn.Open();

            return comm.ExecuteReader();
        }

        private string GetConnected()
        {
            return @"Server=sql.neit.edu\sqlstudentserver,4500;Database=SE245_DSwansey; User Id=SE245_DSwansey; Password=008008985";
        }









        }
    }






