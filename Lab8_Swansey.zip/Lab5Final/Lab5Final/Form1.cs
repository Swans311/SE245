﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Person2;
using Midterm;
using Lab5;
using System.Data.SqlClient;


namespace Lab5Final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public Form1(int intPersonID)
        {
            InitializeComponent();

            PersonV2 temp = new PersonV2();
            SqlDataReader dr = temp.FindOnePerson(intPersonID);

            while (dr.Read())
            {
                Fnametxt.Text = dr["FName"].ToString();
                Mnametxt.Text= dr["MName"].ToString();
                Lnametxt.Text= dr["LName"].ToString();
                street1txt.Text= dr["Street1"].ToString();
                street2txt.Text= dr["Street2"].ToString();
                citytxt.Text= dr["City"].ToString();
                statetxt.Text= dr["State"].ToString();
                ziptxt.Text = dr["Zipcode"].ToString();
                emailtxt.Text = dr["Email"].ToString();
                phonetxt.Text = dr["PhoneNumber"].ToString();
                celltxt.Text = dr["cellNumber"].ToString();
                instagramtxt.Text = dr["Instagram"].ToString();
                lblPersonID.Text = dr["PersonID"].ToString();
                lblPersonID.Text = dr["PersonID"].ToString();
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void State_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void street1_Click(object sender, EventArgs e)
        {

        }

        private void Mname_Click(object sender, EventArgs e)
        {

        }

        private void Fname_Click(object sender, EventArgs e)
        {

        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2();

            temp.FName = Fnametxt.Text;
            temp.MName = Mnametxt.Text;
            temp.LName = Lnametxt.Text;
            temp.Street1 = street1txt.Text;
            temp.Street2 = street2txt.Text;
            temp.city = citytxt.Text;
            temp.state = statetxt.Text;

            int numcheck;
            bool blnResult = false;

            blnResult = Int32.TryParse(ziptxt.Text, out numcheck);
            if(blnResult==false)
            {
                temp.Zipcode = "ERR";
                lblFeedback.Text = "ERROR: Zip Code Must be numeric characters only";
            }
            else
            {
                temp.Zipcode = numcheck.ToString();
            }

            //temp.Zipcode = ziptxt.Text;
            //temp.PhoneNumber = phonetxt.Text;
            temp.Email = emailtxt.Text;
            //temp.cellNumber = celltxt.Text;
            blnResult = Int32.TryParse(celltxt.Text, out numcheck);
            if (blnResult == false)
            {
                temp.cellNumber = "ERROR";
                lblFeedback.Text = "ERROR: Cell Number Must be numeric characters only";
            }
            else
            {
                temp.cellNumber = numcheck.ToString();
            }
            temp.instagram = instagramtxt.Text;

            blnResult = Int32.TryParse(phonetxt.Text, out numcheck);
            if (blnResult == false)
            {
                temp.PhoneNumber = "ERROR";
                lblFeedback.Text += "ERROR: Phone Number Must be numeric characters only";
            }
            else
            {
                temp.PhoneNumber = numcheck.ToString();
                
            }


            if (temp.FName.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if(temp.MName.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.LName.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.Street1.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.city.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.state.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            //else if (temp.Zipcode.Contains("ERROR"))
            //{
                //lblFeedback.Text = temp.feedback;
            //}
            //else if (temp.PhoneNumber.Contains("ERROR"))
            //{
                //lblFeedback.Text = temp.feedback;
            //}
            else if (temp.Email.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            //else if (temp.cellNumber.Contains("ERROR"))
            //{
                //lblFeedback.Text = temp.feedback;
            //}


            if (!temp.feedback.Contains("ERROR"))
            {
                lblFeedback.Text = temp.AddARecord();
            }
            else
            {
                lblFeedback.Text = temp.feedback;
            }







            //else
            //{

                //lblFeedback.Text = ($"{temp.FName} {temp.MName} {temp.LName} \nLocated at: {temp.Street1} {temp.Street2} in {temp.city}, {temp.state} {temp.Zipcode} \nCan be contacted via Phone: {temp.PhoneNumber} or Email: {temp.Email} \nCell Phone Number: {temp.cellNumber} and found on Instagram: @{temp.instagram}");
                //lblFeedback.Text += (strResult);
                //;
            //}
            



        }

        private void btndel_Click(object sender, EventArgs e)
        {
            Int32 intPersonID = Convert.ToInt32(lblPersonID.Text);

            PersonV2 temp = new PersonV2();

            lblFeedback.Text = temp.DeleteOnePerson(intPersonID);
        }

        private void btnup_Click(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2();

            temp.FName = Fnametxt.Text;
            temp.MName = Mnametxt.Text;
            temp.LName = Lnametxt.Text;
            temp.Street1 = street1txt.Text;
            temp.Street2 = street2txt.Text;
            temp.city = citytxt.Text;
            temp.state = statetxt.Text;
            temp.PersonID = Convert.ToInt32(lblPersonID.Text);
            int numcheck;
            bool blnResult = false;

            blnResult = Int32.TryParse(ziptxt.Text, out numcheck);
            if (blnResult == false)
            {
                temp.Zipcode = "ERR";
                lblFeedback.Text = "ERROR: Zip Code Must be numeric characters only";
            }
            else
            {
                temp.Zipcode = numcheck.ToString();
            }

            temp.Email = emailtxt.Text;
            blnResult = Int32.TryParse(celltxt.Text, out numcheck);
            if (blnResult == false)
            {
                temp.cellNumber = "ERROR";
                lblFeedback.Text = "ERROR: Cell Number Must be numeric characters only";
            }
            else
            {
                temp.cellNumber = numcheck.ToString();
            }
            temp.instagram = instagramtxt.Text;

            blnResult = Int32.TryParse(phonetxt.Text, out numcheck);
            if (blnResult == false)
            {
                temp.PhoneNumber = "ERROR";
                lblFeedback.Text += "ERROR: Phone Number Must be numeric characters only";
            }
            else
            {
                temp.PhoneNumber = numcheck.ToString();

            }

            if (!temp.feedback.Contains("ERROR"))
            {
                lblFeedback.Text = temp.UpdateARecord();
            }
            else
            {
                lblFeedback.Text = temp.feedback;
            }



        }








    }
}
