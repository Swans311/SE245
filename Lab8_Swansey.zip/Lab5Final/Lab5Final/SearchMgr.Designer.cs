﻿namespace Lab5Final
{
    partial class SearchMgr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EmailLbl = new System.Windows.Forms.Label();
            this.LnameLbl = new System.Windows.Forms.Label();
            this.txtmail = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.searchbtn = new System.Windows.Forms.Button();
            this.dgvresult = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvresult)).BeginInit();
            this.SuspendLayout();
            // 
            // EmailLbl
            // 
            this.EmailLbl.AutoSize = true;
            this.EmailLbl.Location = new System.Drawing.Point(247, 169);
            this.EmailLbl.Name = "EmailLbl";
            this.EmailLbl.Size = new System.Drawing.Size(71, 25);
            this.EmailLbl.TabIndex = 0;
            this.EmailLbl.Text = "Email:";
            // 
            // LnameLbl
            // 
            this.LnameLbl.AutoSize = true;
            this.LnameLbl.Location = new System.Drawing.Point(197, 314);
            this.LnameLbl.Name = "LnameLbl";
            this.LnameLbl.Size = new System.Drawing.Size(121, 25);
            this.LnameLbl.TabIndex = 1;
            this.LnameLbl.Text = "Last Name:";
            // 
            // txtmail
            // 
            this.txtmail.Location = new System.Drawing.Point(381, 166);
            this.txtmail.Name = "txtmail";
            this.txtmail.Size = new System.Drawing.Size(411, 31);
            this.txtmail.TabIndex = 2;
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(381, 314);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(411, 31);
            this.txtLName.TabIndex = 3;
            // 
            // searchbtn
            // 
            this.searchbtn.Location = new System.Drawing.Point(562, 362);
            this.searchbtn.Name = "searchbtn";
            this.searchbtn.Size = new System.Drawing.Size(230, 46);
            this.searchbtn.TabIndex = 4;
            this.searchbtn.Text = "Submit Search";
            this.searchbtn.UseVisualStyleBackColor = true;
            this.searchbtn.Click += new System.EventHandler(this.searchbtn_Click);
            // 
            // dgvresult
            // 
            this.dgvresult.ColumnHeadersHeight = 46;
            this.dgvresult.Location = new System.Drawing.Point(65, 498);
            this.dgvresult.Name = "dgvresult";
            this.dgvresult.RowHeadersWidth = 82;
            this.dgvresult.Size = new System.Drawing.Size(1176, 344);
            this.dgvresult.TabIndex = 0;
            this.dgvresult.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvresult_CellDoubleClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(451, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(285, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Fill in info for one field below";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(368, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(424, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Filling in no information will show all results";
            // 
            // SearchMgr
            // 
            this.ClientSize = new System.Drawing.Size(1347, 901);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvresult);
            this.Controls.Add(this.searchbtn);
            this.Controls.Add(this.txtLName);
            this.Controls.Add(this.txtmail);
            this.Controls.Add(this.LnameLbl);
            this.Controls.Add(this.EmailLbl);
            this.Name = "SearchMgr";
            this.Text = "SearchMgr";
            ((System.ComponentModel.ISupportInitialize)(this.dgvresult)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvResults;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Fname;
        private System.Windows.Forms.TextBox Fnametxt;
        private System.Windows.Forms.TextBox Lnametxt;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label EmailLbl;
        private System.Windows.Forms.Label LnameLbl;
        private System.Windows.Forms.TextBox txtmail;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.Button searchbtn;
        private System.Windows.Forms.DataGridView dgvresult;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}