﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Person2;
using Midterm;
using Lab5;
using System.Data.SqlClient;
using Lab5Final;



namespace Lab5Final
{
    public partial class SearchMgr : Form
    {
        public SearchMgr()
        {
            InitializeComponent();
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            PersonV2 temp = new PersonV2();

            string mail = txtmail.Text;
            string last = txtLName.Text;

            DataSet ds = temp.SearchPersonV2(mail,last);

            dgvresult.DataSource = ds;

            dgvresult.DataMember = ds.Tables["personv2_Temp"].ToString();
        }

        private void dgvresult_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string strPersonID = dgvresult.Rows[e.RowIndex].Cells[0].Value.ToString();

            MessageBox.Show(strPersonID);

            int intPersonID = Convert.ToInt32(strPersonID);

            Form1 Editor = new Form1(intPersonID);
            Editor.ShowDialog();

        }


 
    }
}
