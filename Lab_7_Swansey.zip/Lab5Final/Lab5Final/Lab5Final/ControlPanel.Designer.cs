﻿namespace Lab5Final
{
    partial class ControlPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reviewbtn = new System.Windows.Forms.Button();
            this.AddARecordbtn = new System.Windows.Forms.Button();
            this.optiontxt = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // reviewbtn
            // 
            this.reviewbtn.Location = new System.Drawing.Point(183, 504);
            this.reviewbtn.Name = "reviewbtn";
            this.reviewbtn.Size = new System.Drawing.Size(190, 59);
            this.reviewbtn.TabIndex = 35;
            this.reviewbtn.Text = "Review Records";
            this.reviewbtn.UseVisualStyleBackColor = true;
            this.reviewbtn.Click += new System.EventHandler(this.reviewbtn_Click);
            // 
            // AddARecordbtn
            // 
            this.AddARecordbtn.Location = new System.Drawing.Point(695, 504);
            this.AddARecordbtn.Name = "AddARecordbtn";
            this.AddARecordbtn.Size = new System.Drawing.Size(190, 59);
            this.AddARecordbtn.TabIndex = 36;
            this.AddARecordbtn.Text = "Add A Record";
            this.AddARecordbtn.UseVisualStyleBackColor = true;
            this.AddARecordbtn.Click += new System.EventHandler(this.AddARecordbtn_Click);
            // 
            // optiontxt
            // 
            this.optiontxt.AutoSize = true;
            this.optiontxt.Location = new System.Drawing.Point(420, 131);
            this.optiontxt.Name = "optiontxt";
            this.optiontxt.Size = new System.Drawing.Size(252, 25);
            this.optiontxt.TabIndex = 37;
            this.optiontxt.Text = "SELECT YOUR OPTION:";
            // 
            // ControlPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1120, 889);
            this.Controls.Add(this.optiontxt);
            this.Controls.Add(this.AddARecordbtn);
            this.Controls.Add(this.reviewbtn);
            this.Name = "ControlPanel";
            this.Text = "ControlPanel";
            this.Load += new System.EventHandler(this.ControlPanel_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button reviewbtn;
        private System.Windows.Forms.Button AddARecordbtn;
        private System.Windows.Forms.Label optiontxt;
    }
}