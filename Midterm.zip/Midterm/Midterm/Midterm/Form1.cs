﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Person temp = new Person();
            temp.FName = txtFname.Text;
            temp.MName = txtMname.Text;
            temp.LName = txtLname.Text;
            temp.Street1 = txtStreet1.Text;
            temp.Street2 = txtStreet2.Text;
            temp.city = txtCity.Text;
            temp.state = txtState.Text;
            temp.Zip = txtZip.Text;
            temp.Phone = txtPhone.Text;
            temp.Email = txtEmail.Text;


            if (temp.Email.Contains("INVALID"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.Phone.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.Zip.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else if (temp.state.Contains("ERROR"))
            {
                lblFeedback.Text = temp.feedback;
            }
            else
            {
                lblFeedback.Text = ($" {temp.FName} {temp.MName} {temp.LName} \n Located at: {temp.Street1} {temp.Street2} in {temp.city}, {temp.state} {temp.Zip} \n Can be contacted via Phone: {temp.Phone} or Email: {temp.Email}");
            }
        }
    }
}
