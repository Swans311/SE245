﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidationLibrary
{
    class Program
    {
        class ValidationLibrary
        {

            public static bool GotPoop(string temp)
            {
                bool result = false;
                if (temp.Contains("Poopy"))
                {
                    result = true;
                }
                return result;
            }

            public static bool IsItFilledIn(string temp)
            {
                bool result = false;
                if (temp.Length > 0)
                {
                    result = true;
                }
                return result;
            }

            public static bool IsItFilledIn(string temp, int minlen)
            {
                bool result = false;
                if (temp.Length >= minlen)
                {
                    result = true;
                }
                return result;
            }

            public static bool IsItTooLong(string temp, int maxlen)
            {
                bool result = false;
                if (temp.Length <= maxlen)
                {
                    result = true;
                }
                return result;
            }

            //Making an email validity checker
            public static bool IsValidEmail(string temp)
            {
                bool blnresult = true;
                int atLocation = temp.IndexOf("@");
                int NextatLocation = temp.IndexOf("@", atLocation + 1);

                int periodLocation = temp.LastIndexOf(".");
                if (temp.Length < 8)
                {
                    blnresult = false;
                }
                else if (atLocation < 2)
                {
                    blnresult = false;
                }
                else if (periodLocation + 2 > (temp.Length))
                {
                    blnresult = false;
                }
                return blnresult;
            }

            public static bool IsMinimumAmount(double temp, double min)
            {
                bool blnresult;

                if (temp >= min)
                {
                    blnresult = true;
                }
                else
                {
                    blnresult = false;
                }
                return blnresult;
            }

        }
        static void Main(string[] args)
        {
        }
    }
}
