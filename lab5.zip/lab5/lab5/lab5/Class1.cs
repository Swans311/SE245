﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Midterm;


namespace Midterm
{
    class ValidationLibrary
    {

        public static bool GotPoop(string temp)
        {
            bool result = false;
            if (temp.Contains("Poopy"))
            {
                result = true;
            }
            return result;
        }

        public static bool IsItFilledIn(string temp)
        {
            bool result = false;
            if (temp.Length > 0)
            {
                result = true;
            }
            return result;
        }

        public static bool IsItFilledIn(string temp, int minlen)
        {
            bool result = false;
            if (temp.Length >= minlen)
            {
                result = true;
            }
            return result;
        }

        public static bool IsItFilledIn(int temp, int minamt)
        {
            bool result = false;
            if(temp>= minamt)
            {
                result = true;
            }
            return result;
        }

        public static bool IsItFilledIn(double temp, double minamt)
        {
            bool result = false;
            if(temp>=minamt)
            {
                result = true;
            }
            return result;
        }

        public static bool IsItTooLong(string temp, int maxlen)
        {
            bool result = false;
            if (temp.Length <= maxlen)
            {
                result = true;
            }
            return result;
        }

        //Making an email validity checker
        public static bool IsValidEmail(string temp)
        {
            bool blnresult = true;
            int atLocation = temp.IndexOf("@");
            int NextatLocation = temp.IndexOf("@", atLocation + 1);

            int periodLocation = temp.LastIndexOf(".");
            if (temp.Length < 8)
            {
                blnresult = false;
            }
            else if (atLocation < 2)
            {
                blnresult = false;
            }
            else if (periodLocation + 2 > (temp.Length))
            {
                blnresult = false;
            }
            return blnresult;
        }

        public static bool IsMinimumAmount(double temp, double min)
        {
            bool blnresult;

            if (temp >= min)
            {
                blnresult = true;
            }
            else
            {
                blnresult = false;
            }
            return blnresult;
        }

        public static bool IsMinimumAmount(int temp, int min)
        {
            bool blnResult;
            if(temp>=min)
            {
                blnResult = true;
            }
            else
            {
                blnResult = false;
            }
            return blnResult;
        }

        public static bool IsAPastDate(DateTime temp)
        {
            bool blnResult = false;
            if (temp <= DateTime.Now)
            {
                blnResult = true;
            }
            else
            {
                blnResult = false;
            }
            return blnResult;
        }

    }
    class Person
    {
        //creating all variables for the person struct/class
        private string Fname;
        private string Mname;
        private string Lname;
        private string street1;
        private string street2;
        private string City;
        private string State;
        private string zipcode;
        private string phone;
        private string email;
        private string Feedback = "";


        //all strings below are referenced as public, so that we are able to access the private strings stored into the Person Class
        //Otherwise we would not be able to pull the information
        public string FName
        {
            get
            {
                return Fname; //returns the value of the Fname PRIVATE variable
            }
            set
            {//Fname variable will be passed into the "Poopy Checker"
                //if (ValidationLibrary.GotPoop(value))
                { //if the name contains 'Poopy' leave it as is
                    if (ValidationLibrary.IsItFilledIn(value))
                    {
                        Fname = value;
                    }
                    else
                    {
                        feedback += "\nERROR First Name must be filled in";
                        //Fname = "ERROR";
                    } //sets the Fname var as value, which is then given to the public string FName
                }
                // else COMMENTING OUT GET POOP REFERENCES
                //{//otherwise we add poopy to the original value of fname
                //Fname = value + " Poopy";
                //}
            }
        }
        //Below (until Email) are just utilizing basic get/set methods, nothing was to be changed for them

        public string feedback
        {
            get
            {
                return Feedback;
            }
            set
            {
                Feedback = value;
            }
        }

        public string MName
        {
            get
            {
                return Mname;
            }
            set
            {
                Mname = value;
            }
        }

        public string LName
        {
            get
            {
                return Lname;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value))
                {
                    Lname = value;
                }
                else
                {
                    feedback += "\nERROR Last Name must be filled in";
                    //Lname = "ERROR";
                }
            }
        }

        public string Street1
        {
            get
            {
                return street1;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value))
                {
                    street1 = value;
                }
                else
                {
                    feedback += "\nERROR Street must be filled in";
                    //street1 = "ERROR";
                }
            }
        }

        public string Street2
        {
            get
            {
                return street2;
            }
            set
            {
                street2 = value;
            }
        }

        public string city
        {
            get
            {
                return City;
            }
            set
            {
                if(ValidationLibrary.IsItFilledIn(value))
                {
                    City = value;
                }
                else
                {
                    feedback += "\nERROR City must be filled in.";
                    //City = "ERROR";
                }
            }
        }

        public string state
        {
            get
            {
                return State;
            }
            set
            {
                if(ValidationLibrary.IsItFilledIn(value,2))
                {
                    State = value;
                }
                else
                {
                    feedback += "\nERROR State Not Long Enough";
                    //State = "ERROR";
                }
            }
        }

        public string Zip
        {
            get
            {
                return zipcode;
            }
            set
            {
                if (ValidationLibrary.IsItFilledIn(value, 5))
                {
                zipcode = value;
                }
                else
                {
                    feedback += "\nERROR: Zip Code not long enough";
                    //zipcode = "ERROR: Zip Code not long enough";
                }
            }
        }

        public string Phone
        {
            get
            {
                return phone;
            }
            set
            {
                if(ValidationLibrary.IsItFilledIn(value,10))
                {
                    phone = value;
                }
                else
                {
                    feedback += "\nERROR: Phone number not long enough";
                    //phone = "ERROR";
                }
            }
        }

        public string Email //using get set method to pull private email variable
        {
            get
            {
                return email;
            }
            set
            {//inserting Email Validity checker
             //if the user typed in an @ symbol and  an extention after, the user input for email passes inspection
                if (ValidationLibrary.IsValidEmail(value))
                {
                    email = value;
                }
                else
                {//if the above conditions are not met, the email evaluates as invalid
                    feedback += "\nERROR invalid Email format";
                    //email = "INVALID";
                }
            }
        }
        public Person()
            {
            Fname = "";
            Mname = "";
            Lname = "";
            street1="";
            street2="";
            City="";
            State="";
            zipcode="";
            phone="";
            email="";
            Feedback = "";

    }
    }
}

class PersonV2 : Person
{
    private string CellPhone;
    private string Instagram;

    public string cellphone
    {
        get
        {
            return CellPhone;
        }
        set
        {
            if (ValidationLibrary.IsItFilledIn(value, 10))
            {
                CellPhone = value;
            }
            else
            {
                feedback += "\nERROR: Cell number not long enough";
                CellPhone = "ERROR";
            }
        }
    }

    public string instagram
    {
        get
        {
            return Instagram;
        }
        set
        {
            if(ValidationLibrary.IsItFilledIn(value))
            {
                Instagram = value;
            }
            else
            {
                feedback += "\nERROR Instagram Handle too short";
                Instagram = "ERROR";
            }
        }
    }

    public PersonV2():base()
    {
        CellPhone = "";
        Instagram = "";
    }



}


class Customer: PersonV2
{
    private DateTime CustomerSince; //IsAPastDate
    private Double TotalPurchases; //IsMinimumAmount(double temp, double min)
    private bool DiscountMember; //Try using a Yes or no button on form page...
    private Int32 RewardsEarned;//IsMinimumAmount(int temp, int min)
    public string ttlpur;
    public string reward;
    public DateTime customersince
    {
        get
        {
            return CustomerSince;
        }
        set
        {
            if (ValidationLibrary.IsAPastDate(value))
            {
                CustomerSince = value;
            }
            else
            {
                feedback += "\nERROR: Must enter Date from today or prior";
            }
        }
    }
    public Double totalpurchases
    {
        get
        {
            return TotalPurchases;
        }
        set
        {
            if(ValidationLibrary.IsMinimumAmount(value,0) && ValidationLibrary.IsItFilledIn(value,0))
            {
                TotalPurchases = value;
            }
            else
            {
                TotalPurchases = -1;
                feedback += "\nERROR: Purchases must be 1 or greater";
            }
        }
    }
    public bool discountmember
    {
        get
        {
            return DiscountMember;
        }
        set
        {
            DiscountMember = value;
        }
    }

    public int rewardsearned
    {
        get
        {
            return RewardsEarned;
        }
        set
        {
            if(ValidationLibrary.IsMinimumAmount(value,0) && ValidationLibrary.IsItFilledIn(value,0))//some people may have never earned rewards...
            {
                RewardsEarned = value;
            }
            else
            {
                RewardsEarned = -1;
                feedback += "ERROR Rewards Earned must be 0 or higher";
            }
        }
    }
    public Customer():base()
    {
        customersince = DateTime.Now;
        totalpurchases = 0;
        discountmember = false;
        rewardsearned = 0;


    }

    }
